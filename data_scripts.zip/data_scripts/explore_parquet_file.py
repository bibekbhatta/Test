# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 17:23:28 2026

@author: bibek
"""

import pandas as pd
df = pd.read_parquet("firms_panel.parquet")
print(df.head())
print(df.columns)
