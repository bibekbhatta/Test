# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 16:52:09 2026

@author: bibek
Business School HPC Demo: OLS Estimation and Visualization
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# 1. Create logs directory if it does not exist
os.makedirs("logs", exist_ok=True)

# 2. Load panel dataset
print("Loading data from firms_panel.csv...")
df = pd.read_csv("firms_panel.csv")
print(f"Successfully loaded {len(df)} rows.")

# 3. Define dependent (y) and independent (X) variables
feature_cols = ['market_excess_return', 'size', 'book_to_market']
X = df[feature_cols]
y = df['firm_excess_return']

# 4. Fit linear regression model
print("Fitting linear regression model...")
model = LinearRegression()
model.fit(X, y)

# 5. Print coefficients to standard output (captured in the SLURM .out file)
print("\n--- Regression Coefficients ---")
print(f"Intercept: {model.intercept_:.4f}")
for col, coef in zip(feature_cols, model.coef_):
  print(f"Beta ({col}): {coef:.4f}")
print("-------------------------------\n")

# 6. Also write results directly to a file inside logs/
with open("logs/regression_results.txt", "w") as f:
  f.write("=== ESTIMATION RESULTS ===\n")
  f.write(f"Intercept: {model.intercept_:.4f}\n")
  for col, coef in zip(feature_cols, model.coef_):
    f.write(f"Beta ({col}): {coef:.4f}\n")
print("Saved summary text to logs/regression_results.txt")

# 7. Generate scatter plot & fitted line
print("Generating plot...")
plt.figure(figsize=(8, 5))

# Scatter observed points
plt.scatter(
    df['market_excess_return'],
    df['firm_excess_return'],
    alpha=0.4,
    color='blue',
    label='Observed Returns',
)

# Create values for the fitted line across the market return range
mkt_grid = np.linspace(
    df['market_excess_return'].min(), df['market_excess_return'].max(), 100
)
synth_data = pd.DataFrame({
    'market_excess_return': mkt_grid,
    'size': df['size'].mean(),
    'book_to_market': df['book_to_market'].mean(),
})
fitted_values = model.predict(synth_data)

plt.plot(mkt_grid, fitted_values, color='red', linewidth=2, label='Fitted Line')
plt.title('CAPM Regression Fit')
plt.xlabel('Market Excess Return')
plt.ylabel('Firm Excess Return')
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()

# 8. Save image file into logs/
plt.savefig('logs/regression_plot.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved visualization to logs/regression_plot.png")
print("Script execution completed successfully!")