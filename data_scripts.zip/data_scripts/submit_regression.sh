#!/bin/bash
#SBATCH --job-name=regr
#SBATCH --partition=standard
#SBATCH --time=00:15:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --output=logs/regression_%j.out
#SBATCH --error=logs/regression_%j.err


# 1. Create logs directory if it doesn't exist yet
mkdir -p logs

# 2. Purge existing environment and load Miniforge
module purge
module load miniforge/python-3.12.10/25.3.0

# 3. Execute the Python script
python run_regression.py
